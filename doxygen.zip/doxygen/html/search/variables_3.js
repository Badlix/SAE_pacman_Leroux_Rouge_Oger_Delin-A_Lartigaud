var searchData=
[
  ['losesentence_0',['loseSentence',['../constants_8h.html#a619acc31feecf117ccf56ab84c291829',1,'constants.h']]]
];
