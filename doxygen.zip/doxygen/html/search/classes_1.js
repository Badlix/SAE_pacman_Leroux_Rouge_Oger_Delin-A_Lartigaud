var searchData=
[
  ['character_0',['Character',['../struct_character.html',1,'']]]
];
