var searchData=
[
  ['fruitskins_0',['fruitSkins',['../constants_8h.html#a3f4429733c2b0d1983cdb1438d25827b',1,'constants.h']]]
];
