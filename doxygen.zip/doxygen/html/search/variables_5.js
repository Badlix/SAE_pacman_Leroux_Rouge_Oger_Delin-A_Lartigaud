var searchData=
[
  ['pos_0',['pos',['../struct_character.html#a375c67ee7ef3239de4896b78f593b43d',1,'Character']]]
];
