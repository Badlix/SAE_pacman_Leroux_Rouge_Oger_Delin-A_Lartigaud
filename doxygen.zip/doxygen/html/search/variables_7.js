var searchData=
[
  ['skinghostcolors_0',['skinGhostColors',['../constants_8h.html#aa2f6513c75816bc928d93308efe93b08',1,'constants.h']]],
  ['skins_1',['skins',['../struct_pacman_mouth.html#a88904fd3ff11969fbbe07cadaa1c3ea2',1,'PacmanMouth::skins()'],['../struct_character.html#adb0ae5e302d509770c3f9d4531d63136',1,'Character::skins()'],['../struct_param.html#a89c892476a0eaac6979ce8b9f4e5c4a8',1,'Param::skins()'],['../struct_autorized_keys.html#a800f3e2525bac8780ae0794bb9231ec8',1,'AutorizedKeys::skins()']]],
  ['sprite_2',['sprite',['../struct_character.html#a006d497aeff83c938450393fa9e358d2',1,'Character']]]
];
