var searchData=
[
  ['initialization_2ecpp_0',['initialization.cpp',['../initialization_8cpp.html',1,'']]],
  ['initialization_2eh_1',['initialization.h',['../initialization_8h.html',1,'']]]
];
