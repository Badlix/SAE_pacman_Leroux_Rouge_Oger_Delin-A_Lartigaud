var searchData=
[
  ['y_0',['y',['../struct_position.html#a0fcd0edfb89457763f7331f1b6df6478',1,'Position']]]
];
