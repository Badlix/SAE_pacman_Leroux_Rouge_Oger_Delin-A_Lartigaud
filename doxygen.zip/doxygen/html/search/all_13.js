var searchData=
[
  ['winsentence_0',['winSentence',['../constants_8h.html#a7a09919f6ebcf746ce22dfd099878758',1,'constants.h']]]
];
