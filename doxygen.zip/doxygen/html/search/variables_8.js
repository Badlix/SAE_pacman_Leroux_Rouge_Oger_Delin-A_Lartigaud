var searchData=
[
  ['type_0',['type',['../struct_character.html#a0c3dd0d7a9f7a5fec5bfd90508d8d8dc',1,'Character']]]
];
