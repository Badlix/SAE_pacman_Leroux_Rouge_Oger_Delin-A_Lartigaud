var initialization_8h =
[
    [ "initCharacters", "initialization_8h.html#a37119ba4c63486bd70f6145368a06720", null ],
    [ "initMaze", "initialization_8h.html#a5959a109da2bcabca4402db0a9de94c7", null ],
    [ "initMusicsEngine", "initialization_8h.html#a4e7df9e43241611159fd2ce69dd27bbd", null ],
    [ "initPacmanmouth", "initialization_8h.html#ab7748396f9ce97426eacae784594c02b", null ],
    [ "initPersonality", "initialization_8h.html#a05874b59a37debd7613c4d3a3d73b8c3", null ],
    [ "initSkin", "initialization_8h.html#ae9b28621a936d391beaf953f328125ee", null ],
    [ "initWalls", "initialization_8h.html#ab572028d3edea97087721fe4547a4338", null ],
    [ "nbBubbleInMaze", "initialization_8h.html#a0ea7872df3a61b478a2cf0951c424be9", null ]
];