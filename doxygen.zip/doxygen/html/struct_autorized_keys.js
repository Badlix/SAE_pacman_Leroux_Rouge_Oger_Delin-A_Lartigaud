var struct_autorized_keys =
[
    [ "difficulty", "struct_autorized_keys.html#ab9ea752fa28a8fff18e6a3d8bce55848", null ],
    [ "moveKeys", "struct_autorized_keys.html#ad4126d37b25c0d62f726e5021c057c3d", null ],
    [ "random", "struct_autorized_keys.html#a86c1f5aef1e6451144b31120923429de", null ],
    [ "skins", "struct_autorized_keys.html#a800f3e2525bac8780ae0794bb9231ec8", null ]
];