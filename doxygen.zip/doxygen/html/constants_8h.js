var constants_8h =
[
    [ "Position", "struct_position.html", "struct_position" ],
    [ "Skin", "struct_skin.html", "struct_skin" ],
    [ "PacmanMouth", "struct_pacman_mouth.html", "struct_pacman_mouth" ],
    [ "Character", "struct_character.html", "struct_character" ],
    [ "fruitSkins", "constants_8h.html#a3f4429733c2b0d1983cdb1438d25827b", null ],
    [ "loseSentence", "constants_8h.html#a619acc31feecf117ccf56ab84c291829", null ],
    [ "maze1", "constants_8h.html#a578860512331a2cc1244db3925df5b17", null ],
    [ "maze2", "constants_8h.html#abdcc339d1e568f549ea79437b1ea56d7", null ],
    [ "skinGhostColors", "constants_8h.html#aa2f6513c75816bc928d93308efe93b08", null ],
    [ "winSentence", "constants_8h.html#a7a09919f6ebcf746ce22dfd099878758", null ]
];