var struct_pacman_mouth =
[
    [ "delay", "struct_pacman_mouth.html#ae05b821217f33eec5b01acba17961e29", null ],
    [ "skins", "struct_pacman_mouth.html#a88904fd3ff11969fbbe07cadaa1c3ea2", null ]
];