var struct_skin =
[
    [ "defaultState", "struct_skin.html#a4d8c0e62f69c0dc1f124349b2ec16091", null ],
    [ "madState", "struct_skin.html#a3a458d1dd180146aada32338185e5f08", null ]
];