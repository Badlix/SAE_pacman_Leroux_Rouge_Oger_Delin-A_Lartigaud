var annotated_dup =
[
    [ "AutorizedKeys", "struct_autorized_keys.html", "struct_autorized_keys" ],
    [ "Character", "struct_character.html", "struct_character" ],
    [ "PacmanMouth", "struct_pacman_mouth.html", "struct_pacman_mouth" ],
    [ "Param", "struct_param.html", "struct_param" ],
    [ "Position", "struct_position.html", "struct_position" ],
    [ "Skin", "struct_skin.html", "struct_skin" ]
];