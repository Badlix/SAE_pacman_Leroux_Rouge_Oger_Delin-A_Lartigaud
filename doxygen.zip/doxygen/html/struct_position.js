var struct_position =
[
    [ "operator!=", "struct_position.html#a6358e7bd1a99e5f033f08bc0d364d790", null ],
    [ "operator<", "struct_position.html#a3a769d918ec3ddcbe53ea065e172f5bd", null ],
    [ "operator==", "struct_position.html#a2853571fea1d2591ffb1a74cd352c67f", null ],
    [ "x", "struct_position.html#ad0bbec0e9196cfabea8ee391d946ab4e", null ],
    [ "y", "struct_position.html#a0fcd0edfb89457763f7331f1b6df6478", null ]
];