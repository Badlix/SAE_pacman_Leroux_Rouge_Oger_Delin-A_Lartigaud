var game__logic_8h =
[
    [ "changeEveryoneState", "game__logic_8h.html#a7765c52170ec96b4bc846c8c95df90b1", null ],
    [ "changeState", "game__logic_8h.html#a13238abc3267ae97a10f897d400b92d4", null ],
    [ "checkEating", "game__logic_8h.html#a3b70e6a7d2abb9415d1f3be5a87a29ec", null ],
    [ "eatBubble", "game__logic_8h.html#a816903711d7aaa89b0eb5b70a1a1e8c2", null ],
    [ "eatGhost", "game__logic_8h.html#a00f559aef9c6d67bbc4f79dee7e43027", null ],
    [ "letGhostOut", "game__logic_8h.html#aad082b99d257ff8b68ea4a4c8c40c333", null ],
    [ "moveCharacter", "game__logic_8h.html#a168345b9efed6e83373fa203e4787a3f", null ],
    [ "moveCharacterTeleporter", "game__logic_8h.html#a5a34a41b8cdeee378691828327b3a76d", null ]
];