var struct_param =
[
    [ "difficulty", "struct_param.html#ae156a33441640e5afc671dd414e6e2ef", null ],
    [ "moveKeys", "struct_param.html#a0f436ae55ad72738ee67d4a486937a30", null ],
    [ "skins", "struct_param.html#a89c892476a0eaac6979ce8b9f4e5c4a8", null ]
];