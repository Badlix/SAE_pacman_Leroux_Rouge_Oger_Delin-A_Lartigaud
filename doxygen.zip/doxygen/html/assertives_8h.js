var assertives_8h =
[
    [ "isBigBubble", "assertives_8h.html#a3593934d8c1f903ab20252a9304f3744", null ],
    [ "isBubble", "assertives_8h.html#a7e71af9f16f98780151529065683e6d3", null ],
    [ "isBubbleLeft", "assertives_8h.html#a5399ee2be06c9951cc917eb00528a2f9", null ],
    [ "isEncouterGhostPacman", "assertives_8h.html#a6597cb88146fea8e0069ae50170f7699", null ],
    [ "isFree", "assertives_8h.html#a23b730f99dc9132a7343a500388c27e3", null ],
    [ "isGhostInCage", "assertives_8h.html#a9990c14f211e1c5760b612423b342c6f", null ],
    [ "isMovePossible", "assertives_8h.html#ae7d43ca5ae9ecf9ac8091e377a9c0f29", null ],
    [ "isSamePos", "assertives_8h.html#ac7440ed3b9c179bfbc326f1ae864f871", null ],
    [ "isTeleporter", "assertives_8h.html#a86948ff3bdbd5fd05ed1afccc6bb435f", null ],
    [ "isThereAGhostInCage", "assertives_8h.html#a42d5021eed5d5c0be877c5d2857822c4", null ]
];