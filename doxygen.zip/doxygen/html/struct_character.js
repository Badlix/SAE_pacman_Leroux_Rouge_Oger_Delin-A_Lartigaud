var struct_character =
[
    [ "direction", "struct_character.html#ab7c7c0841913224c83aabffc7713d9d0", null ],
    [ "isDefaultState", "struct_character.html#a8e7cb510ca9a3cf05f03854464be6f9e", null ],
    [ "pos", "struct_character.html#a375c67ee7ef3239de4896b78f593b43d", null ],
    [ "skins", "struct_character.html#adb0ae5e302d509770c3f9d4531d63136", null ],
    [ "sprite", "struct_character.html#a006d497aeff83c938450393fa9e358d2", null ],
    [ "type", "struct_character.html#a0c3dd0d7a9f7a5fec5bfd90508d8d8dc", null ],
    [ "vitesse", "struct_character.html#ac191fb6e62d27320af662b4645e4e7fe", null ]
];